#ifndef DELAY_H__
#define DELAY_H__

#include <stdint.h>

void delay(uint32_t ms);
void delayTicks(uint32_t ticks);

#endif
